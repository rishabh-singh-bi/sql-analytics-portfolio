# HackerRank — Aggregations & Subqueries

Practice covering GROUP BY, HAVING, aggregate functions, subqueries, and nested analytical logic.

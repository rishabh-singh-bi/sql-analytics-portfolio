# HackerRank — Advanced JOINs

Practice covering INNER JOIN, LEFT JOIN, multi-table relationships, and JOIN-based business analysis.

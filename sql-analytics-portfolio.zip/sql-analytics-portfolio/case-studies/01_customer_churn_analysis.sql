/*
===============================================================================
CASE STUDY: CUSTOMER CHURN ANALYSIS
===============================================================================

Author: Rishabh Singh Chauhan
SQL Dialect: PostgreSQL

===============================================================================
1. PROBLEM STATEMENT
===============================================================================

Business question:

Which customers are currently active, which customers have churned, and
which active customers may represent a potential churn risk?

Objectives:
1. Calculate customer-level revenue.
2. Identify active and churned customers.
3. Measure recent customer activity.
4. Classify active customers into risk tiers.
5. Produce a business-ready churn summary.

Assumed tables:
    customers(customer_id, customer_name, signup_date, region)
    subscriptions(subscription_id, customer_id, subscription_start_date,
                  subscription_end_date, subscription_status)
    transactions(transaction_id, customer_id, transaction_date, revenue)
    customer_activity(activity_id, customer_id, activity_date, activity_type)

===============================================================================
2. QUERY
===============================================================================
*/

WITH customer_revenue AS (
    SELECT
        customer_id,
        SUM(revenue) AS total_revenue
    FROM transactions
    GROUP BY customer_id
),
recent_activity AS (
    SELECT
        customer_id,
        MAX(activity_date) AS last_activity_date,
        COUNT(*) FILTER (
            WHERE activity_date >= CURRENT_DATE - INTERVAL '30 days'
        ) AS activities_last_30_days
    FROM customer_activity
    GROUP BY customer_id
),
latest_subscription AS (
    SELECT
        customer_id,
        subscription_status,
        subscription_end_date,
        ROW_NUMBER() OVER (
            PARTITION BY customer_id
            ORDER BY subscription_start_date DESC
        ) AS subscription_rank
    FROM subscriptions
),
customer_metrics AS (
    SELECT
        c.customer_id,
        c.customer_name,
        c.region,
        c.signup_date,
        COALESCE(cr.total_revenue, 0) AS total_revenue,
        ra.last_activity_date,
        COALESCE(ra.activities_last_30_days, 0) AS activities_last_30_days,
        ls.subscription_status,
        ls.subscription_end_date
    FROM customers c
    LEFT JOIN customer_revenue cr
        ON c.customer_id = cr.customer_id
    LEFT JOIN recent_activity ra
        ON c.customer_id = ra.customer_id
    LEFT JOIN latest_subscription ls
        ON c.customer_id = ls.customer_id
       AND ls.subscription_rank = 1
),
churn_classification AS (
    SELECT
        *,
        CASE
            WHEN subscription_status = 'Churned'
                THEN 'Churned'
            WHEN subscription_status = 'Active'
                 AND activities_last_30_days = 0
                THEN 'High Risk'
            WHEN subscription_status = 'Active'
                 AND activities_last_30_days BETWEEN 1 AND 3
                THEN 'Medium Risk'
            WHEN subscription_status = 'Active'
                 AND activities_last_30_days > 3
                THEN 'Low Risk'
            ELSE 'Unknown'
        END AS churn_risk
    FROM customer_metrics
)
SELECT
    customer_id,
    customer_name,
    region,
    signup_date,
    subscription_status,
    total_revenue,
    last_activity_date,
    activities_last_30_days,
    churn_risk
FROM churn_classification
ORDER BY
    CASE churn_risk
        WHEN 'Churned' THEN 1
        WHEN 'High Risk' THEN 2
        WHEN 'Medium Risk' THEN 3
        WHEN 'Low Risk' THEN 4
        ELSE 5
    END,
    total_revenue DESC;

/*
===============================================================================
3. BUSINESS VALUE
===============================================================================

Potential uses:
- Identify churned customers.
- Detect reduced engagement.
- Prioritize retention activity.
- Identify high-value customers at risk.
- Support churn KPI reporting.

Potential BI metrics:
- Customer Churn Rate
- Active Customers
- High-Risk Customers
- Revenue at Risk
- Average Revenue per Customer
- 30-Day Customer Activity
- Churn by Region

===============================================================================
4. POSSIBLE EXTENSIONS
===============================================================================

- Monthly churn rate
- Revenue at risk
- Acquisition-channel churn
- Customer lifetime value
- Cohort retention
- Power BI visualization
===============================================================================
*/

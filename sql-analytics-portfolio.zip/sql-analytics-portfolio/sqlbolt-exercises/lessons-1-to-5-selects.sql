/*
SQLBolt Lessons 1–5
Focus: SELECT, filtering, sorting, and basic querying.

Add completed exercises below as they are solved.
*/

-- Exercise 1: Basic SELECT
-- SELECT *
-- FROM movies;

-- Exercise 2: Filtering
-- SELECT title, year
-- FROM movies
-- WHERE year >= 2000;

-- Exercise 3: Sorting
-- SELECT title, year
-- FROM movies
-- ORDER BY year DESC;

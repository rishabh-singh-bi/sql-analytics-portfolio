/*
SQLBolt Lessons 6–12
Focus: JOINs, aggregation, GROUP BY, HAVING, and related analytical patterns.

Add completed exercises below as they are solved.
*/

-- Example JOIN pattern
-- SELECT
--     orders.order_id,
--     customers.customer_name
-- FROM orders
-- INNER JOIN customers
--     ON orders.customer_id = customers.customer_id;

-- Example aggregation pattern
-- SELECT
--     region,
--     COUNT(*) AS customer_count
-- FROM customers
-- GROUP BY region;
